<?php
/*
Plugin Name: wp-Declutter
Plugin URI: http://www.wp-Declutter.com
Description: Declutter your WordPress site
Version: 1.0
Author: Taylor Arndt
Author URI: http://www.taylorarndt.com
License: GPL2
*/

// Disable support for comments and trackbacks in post types
function declutter_remove_comments_support() {
  $post_types = get_post_types();
  foreach ($post_types as $post_type) {
      if (post_type_supports($post_type, 'comments')) {
          remove_post_type_support($post_type, 'comments');
          remove_post_type_support($post_type, 'trackbacks');
      }
  }
}
add_action('admin_init', 'declutter_remove_comments_support');

// Close comments on the front-end
function declutter_disable_comments_status() {
  return false;
}
add_filter('comments_open', 'declutter_disable_comments_status', 20, 2);
add_filter('pings_open', 'declutter_disable_comments_status', 20, 2);

// Remove the 'Hello World!' post
function declutter_remove_hello_world_post() {
  $post = get_page_by_title('Hello world!', OBJECT, 'post');
  if ($post) {
      wp_delete_post($post->ID, true);
  }
}
register_activation_hook(__FILE__, 'declutter_remove_hello_world_post');

// Remove 'Sample Page'
function declutter_remove_sample_page() {
  $page = get_page_by_title('Sample Page');
  if ($page) {
      wp_delete_post($page->ID, true);
  }
}
register_activation_hook(__FILE__, 'declutter_remove_sample_page');

// Remove meta widget
function declutter_deregister_widgets() {
  unregister_widget('WP_Widget_Meta');
}
add_action('widgets_init', 'declutter_deregister_widgets');
?>
